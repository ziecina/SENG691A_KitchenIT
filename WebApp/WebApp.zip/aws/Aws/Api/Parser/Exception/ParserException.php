<?php
namespace Aws\Api\Parser\Exception;

class ParserException extends \RuntimeException {}
